package com.google.handouts.myweather.Model;

/**
 * Created by admin on 9/6/2017.
 */

public class Rain {
}
