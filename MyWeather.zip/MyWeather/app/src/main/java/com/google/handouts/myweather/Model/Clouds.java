package com.google.handouts.myweather.Model;

/**
 * Created by admin on 9/6/2017.
 */

public class Clouds {
    private int all;

    public Clouds(int all) {
        this.all = all;
    }

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}
